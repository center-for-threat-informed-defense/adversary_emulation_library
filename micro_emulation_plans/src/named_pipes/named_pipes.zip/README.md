# Micro Emulation Plan: Named Pipes

This micro emulation plan is part of the first sprint of plan development targeting specific data sources of interest. Specifically, this plan targets the **[named pipe](https://attack.mitre.org/datasources/DS0023/)** data source.

[Named pipes](https://docs.microsoft.com/windows/win32/ipc/pipes?redirectedfrom=MSDN) are shared memory used for inter-process communication (IPC), typically as a "file" that allows processes to exchange data (though IPC traffic between hosts may be encapsulated in other protocols such as SMB). Named pipes are commonly abused by malware (ex: [Cobalt Strike](https://labs.f-secure.com/blog/detecting-cobalt-strike-default-modules-via-named-pipe-analysis/)) to while injecting/retrieving payloads and commands. Please see the **CTI / Background** section for more details.

## Description of Emulated Behaviors

**What are we doing?** This module provides easy to execute code for creating then sending data over a named pipe. The module is split into 3 parts:

1. A **server** that creates (using the Windows `CreateNamedPipe()` API) then writes a message to the named pipe
2. A **client** that connects to (using the Windows `CreateFile()` API)  then reads and prints the message from the named pipe
3. Both the client and server are executed by the **executor** program, which also provides the name of the pipe. Pipe names are chosen by the user based on hard-coded values based on [CTI-inspired templates](https://www.cobaltstrike.com/blog/learn-pipe-fitting-for-all-of-your-offense-projects/).

## CTI / Background

**Why should you care?** Named pipes are commonly abused by malware to transfer malicious payloads and/or data between processes ([T1559](https://attack.mitre.org/techniques/T1559/)). Commonly known as a ["Fork-n-Run" pattern](https://labs.f-secure.com/blog/detecting-cobalt-strike-default-modules-via-named-pipe-analysis/), this design helps protect malware by using "sacrificial processes" that may not reveal/highlight the main malware module. Malware such as Cobalt Strike Beacons have utilized this approach while executing malicious component such as code loaders/injector ([T1055](https://attack.mitre.org/techniques/T1055/)) and keyloggers.

Privilege Escalation exploits ([T1068](https://attack.mitre.org/techniques/T1068/)), such as [Cobalt Strike](https://thedfirreport.com/2021/08/29/cobalt-strike-a-defenders-guide/)'s & [Metasploit's getsystem](https://docs.rapid7.com/metasploit/meterpreter-getsystem/), have also abused [named pipe impersonation](https://foxglovesecurity.com/2016/09/26/rotten-potato-privilege-escalation-from-service-accounts-to-system/) to steal tokens ([T1134](https://attack.mitre.org/techniques/T1134/)).

Named pipes may also be created and abused as part of Lateral Movement ([T1021](https://attack.mitre.org/techniques/T1021/), [T1570](https://attack.mitre.org/techniques/T1570/)) or remote Discovery ([T1018](https://attack.mitre.org/techniques/T1018/)) behaviors.

## Execution Instructions / Resources

This module has been compiled into an easy to execute/integrate executable. If you wish to customize and/or build from source code, please see the [building document](BUILD.md). You can also download the pre-compiled modules.

The `namedpipes_executor.exe` executable executes both the server and the client in separate processes, starting the server first to create the pipe and write to it, then starting the client to read what was written.

The `namedpipes_executor.exe` expects `namedpipes_server.exe` and `namedpipes_client.exe` to be in its current working directory.

You can run the executor with no flags set to use its defaults.
```
./namedpipes_executor.exe
```

### Execution - Command Flags

The executor accepts three sets of optional arguments: the `pipe`, the `server`, and the `client`. These terms can occur in any order.

```
./namedpipes_executor.exe --pipe 1 --server namedpipes_server.exe --client namedpipes_client.exe
```

You can also use `help` (with no other parameters) to see a help message.

```
./myexec.exe help

Syntax: --pipe <pipe_type> --server <server_exe> --client <client_exe>
        namedpipes_executor.exe --pipe 1 --server namedpipes_server.exe --client namedpipes_client.exe
If you built this with custom server or client executable names, use those names instead.
        --pipe <pipe_type>: Optional. Number indicating the type of pipe to create. Refer to the "pipe_type options" for acceptable values.
        --server <server_exe>: Optional. Relative path to the server executable.
        --client <client_exe>: Optional. Relative path to the client executable.

The flags can appear in any order.

pipe_type options:
1 - Cobalt Strike Artifact Kit pipe
2 - Cobalt Strike Lateral Movement (psexec_psh) pipe
3 - Cobalt Strike SSH (postex_ssh) pipe
4 - Cobalt Strike post-exploitation pipe (4.2 and later)
5 - Cobalt Strike post-exploitation pipe (before 4.2)

Defaults are:
        pipe_type: 1
        client_exe: namedpipes_client.exe
        server_exe: namedpipes_server.exe
```

#### Execution - Command Flags - The Pipe Flag

```
./namedpipes_executor.exe --pipe 1
```

If this flag is not set, the default "1" is used.

The `--pipe` value is a number from 1 to 5. This is the mapping of values to pipe names:

1. `\\.\pipe\MSSE-a09-server`, inspired by the default Cobalt Strike Artifact Kit pipe (`MSSE-###-server`)
2. `\\.\pipe\status_4f`, inspired by the default Cobalt Strike Lateral Movement pipe (`status_##` created by `psexec_psh`)
3. `\\.\pipe\postex_ssh_ad90`, inspired by the default Cobalt Strike SSH pipe (`postex_ssh_####` created by `postex_ssh`)
4. `\\.\pipe\postex_b83a`, inspired by the default Cobalt Strike v4.2+ post-exploitation pipe (`postex_####`)
5. `\\.\pipe\29fe3b7c1`, inspired by the default Cobalt Strike pre-v.4.2 pipe (7-10 digit hexadecimal value)

#### Execution - Command Flags - The Server Flag

```
./namedpipes_executor.exe --server myserver.exe
```

If this flag is not set, the default "namedpipes_server.exe" is used.

You only need to set this flag if you have customized the server executable name.
See ["Customizing the Executable Names"](BUILD.md#customizing-the-executable-names) for more information.

#### Execution - Command Flags - The Client Flag

```
./namedpipes_executor.exe --client myclient.exe
```

If this flag is not set, the default "namedpipes_client.exe" is used.

You only need to set this flag if you have customized the client executable name.
See ["Customizing the Executable Names"](BUILD.md#customizing-the-executable-names) for more information.

### Customizing the Executables

These hard-coded values can be tailored by modifying the relevant strings then rebuilding the project from source code.

Refer to [Customizing the Executables](BUILD.md#Customizing-The-Executables) in the building document for more details.


### Execution Demo

![demo](docs/pipes.gif)

## Defensive Lessons Learned

### Detection

Sysmon generates [event IDs 17 and 18](https://docs.microsoft.com/en-us/sysinternals/downloads/sysmon#event-id-17-pipeevent-pipe-created) when named pipes are created or connected to. These, and similar events, can be used to both baseline known name pipe patterns (i.e. [pipe names and associated client/server processes](https://github.com/olafhartong/sysmon-modular/tree/master/17_18_pipe_event)) as well as create analytic logic to match on [known malicious pipe name patterns](https://github.com/SigmaHQ/sigma/tree/master/rules/windows/pipe_created).

![image](docs/sigma.png)

Monitoring and/or alerting based solely on pipe names (which may be manipulated by adversaries) may introduce false positives and false negatives (though lists of default values commonly abused by malware are available). Other behaviors such as execution of PowerShell commands (`\PSHost`) or [LDAP queries using tools such as SharpHound.exe](https://blog.menasec.net/2019/02/threat-hunting-7-detecting.html) may also utilize [well-known name pipes](https://thedfirreport.com/2021/08/29/cobalt-strike-a-defenders-guide/).

You can also use [PowerShell to query](https://svch0st.medium.com/guide-to-named-pipes-and-hunting-for-cobalt-strike-pipes-dc46b2c5f575) for all currently open pipes (ex: `Get-ChildItem \\.\pipe\`)

[Anonymous (unnamed) pipes](https://labs.f-secure.com/blog/detecting-cobalt-strike-default-modules-via-named-pipe-analysis/) can also be created and used in the same way as named pipes. These may still trigger the same detection events (ex: Sysmon EID 17) but may be more difficult to create automatic alerts for since the name value will be `Null`. For this reason, it may be advantageous to baseline an environment (ex: which processes commonly create/connect to anonymous pipes?) to provide better context during triage/deeper analysis of potentially malicious telemetry.

Abuse of pipes could also be a fruitful threat hunting activity, for example [the following Splunk query](https://labs.f-secure.com/blog/detecting-cobalt-strike-default-modules-via-named-pipe-analysis/) can be used to search for relatively uncommon/rare processes creating an anonymous pipe:

```
index="YOUR_INDEX" source="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" EventCode=17 PipeName="&lt;Anonymous Pipe&gt;"| rare limit=20 Image
```

You could also monitor named pipes other methods such as [hooking API functions associated with named pipes](https://bmcder.com/blog/cobalt-strike-dfir-listening-to-the-pipes), those this approach may be difficult to scale and distinguish from benign system activity.

### Mitigation

Usage of named pipes may be difficult if not impossible to mitigate since they enable legitimate system use case. Efforts can be rather focused on filtering/blocking/identifying patterns of abuse at both a host and network layer. For the latter, network segmentation can be used to minimize the potential impact of remote named pipe abuse.
